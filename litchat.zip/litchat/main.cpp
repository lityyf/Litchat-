#include <windows.h>
#include <winhttp.h>
#include <string>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <locale>
#include <codecvt>
#include<vector>
#include<stdlib.h>
#include <chrono>
#include <thread>
#include <cmath>
#include <map>
#include <algorithm>
#include <limits>
class RAGMemory {
private:
	struct MemoryItem {
		std::string text;
		std::vector<float> embedding;
	};
	
	std::vector<MemoryItem> memoryDB;
	const int MAX_MEMORY = 50;
	
	
	std::vector<float> textToVector(const std::string& text) {
		std::map<char, int> freq;
		for (char c : text) {
			freq[tolower(c)]++; 
		}
		
	
		std::vector<float> vec(256, 0.0f); 
		float textLen = static_cast<float>(text.length());
		for (auto& [c, count] : freq) {
			int index = static_cast<unsigned char>(c) % 256;
			vec[index] = static_cast<float>(count) / textLen;
		}
		return vec;
	}
	
	
	// 余弦相似度
	float similarity(const std::vector<float>& a, const std::vector<float>& b) {
		float dot = 0, magA = 0, magB = 0;
		for (size_t i = 0; i < a.size(); ++i) {
			dot += a[i] * b[i];
			magA += a[i] * a[i];
			magB += b[i] * b[i];
		}
		return magA && magB ? dot / (sqrt(magA) * sqrt(magB)) : 0;
	}
	
public:
	// 添加记忆
	void addMemory(const std::string& text) {
		if (text.find("钦灵") != std::string::npos || 
			text.find("女朋友") != std::string::npos) {
			memoryDB.insert(memoryDB.begin(), MemoryItem{text, textToVector(text)});
			return;
		}
		if (memoryDB.size() >= MAX_MEMORY) {
			memoryDB.erase(memoryDB.begin());
		}
		memoryDB.push_back({text, textToVector(text)});
	}
	
	// 检索相关记忆
	std::string search(const std::string& query) {
		auto queryVec = textToVector(query);
		float maxScore = 0;
		std::string bestMatch;
		
		for (const auto& item : memoryDB) {
			float score = similarity(queryVec, item.embedding);
			if (score > maxScore && score > 0.25) { // 相似度阈值
				maxScore = score;
				bestMatch = item.text;
			}
		}
		
		return bestMatch.empty() ? "" : "[记忆召回] " + bestMatch;
	}
};

static RAGMemory g_ragMemory;
const std::string API_KEY = "";//your deepseek api-key

void SetUTF8Locale() {
	SetConsoleOutputCP(65001); 
	std::locale::global(std::locale(""));
	std::wcout.imbue(std::locale());
	std::wcin.imbue(std::locale());
}

std::string EscapeJsonString(const std::string& input) {
	std::ostringstream ss;
	for (char c : input) {
		switch (c) {
			case '"': ss << "\\\""; break;
			case '\\': ss << "\\\\"; break;
			case '\b': ss << "\\b"; break;
			case '\f': ss << "\\f"; break;
			case '\n': ss << "\\n"; break;
			case '\r': ss << "\\r"; break;
			case '\t': ss << "\\t"; break;
		default:
			if (static_cast<unsigned char>(c) < 0x20 || c == 0x7F) {
				ss << "\\u" << std::hex << std::setw(4) << std::setfill('0') 
				<< static_cast<int>(c);
			} else {
				ss << c;
			}
		}
	}
	return ss.str();
}

std::string WinHttpRequest(const std::string& prompt) {
	HINTERNET hSession = NULL, hConnect = NULL, hRequest = NULL;
	std::string response;
	
	try {
		
		hSession = WinHttpOpen(L"DeepSeek Client/1.0", 
			WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
			NULL, NULL, 0);
		if (!hSession) throw "WinHttpOpen failed";
		
		hConnect = WinHttpConnect(hSession, 
			L"api.deepseek.com",
			INTERNET_DEFAULT_HTTPS_PORT, 0);
		if (!hConnect) throw "WinHttpConnect failed";
		
		hRequest = WinHttpOpenRequest(hConnect,
			L"POST",
			L"/v1/chat/completions",
			NULL, NULL, NULL,
			WINHTTP_FLAG_SECURE);
		if (!hRequest) throw "WinHttpOpenRequest failed";
		
		std::wstring headers = 
		L"Content-Type: application/json\r\n"
		L"Authorization: Bearer " + std::wstring(API_KEY.begin(), API_KEY.end()) +
		L"\r\nAccept-Charset: utf-8";
		
		if (!WinHttpAddRequestHeaders(hRequest,
			headers.c_str(),
			-1L,
			WINHTTP_ADDREQ_FLAG_ADD)) {
			throw "WinHttpAddRequestHeaders failed";
		}
		
		std::string escapedPrompt = EscapeJsonString(prompt);
		std::string requestBody = 
		R"({"model":"deepseek-chat","messages":[{"role":"system","content":"请使用简体中文回答"},{"role":"user","content":")" 
		+ escapedPrompt + R"("}],"temperature":0.7})";
		
		if (!WinHttpSendRequest(hRequest,
			NULL, 0,
			(LPVOID)requestBody.data(),
			requestBody.size(),
			requestBody.size(), 0)) {
			throw "WinHttpSendRequest failed";
		}
		
		if (!WinHttpReceiveResponse(hRequest, NULL)) {
			throw "WinHttpReceiveResponse failed";
		}
		
		DWORD size = 0;
		do {
			if (!WinHttpQueryDataAvailable(hRequest, &size)) {
				throw "WinHttpQueryDataAvailable failed";
			}
			
			if (size > 0) {
				std::vector<char> buffer(size + 1);
				DWORD downloaded = 0;
				
				if (!WinHttpReadData(hRequest, 
					buffer.data(), 
					size, 
					&downloaded)) {
					throw "WinHttpReadData failed";
				}
				response.append(buffer.data(), downloaded);
			}
		} while (size > 0);
		
	} catch (const char* error) {
		std::cerr << "[ERROR] " << error 
		<< " (Code: " << GetLastError() << ")\n";
		response = "{\"error\":\"Request failed\"}";
	}
	
	
	if (hRequest) WinHttpCloseHandle(hRequest);
	if (hConnect) WinHttpCloseHandle(hConnect);
	if (hSession) WinHttpCloseHandle(hSession);
	
	return response;
}

std::string ExtractContent(const std::string& jsonResponse) {
	size_t pos = jsonResponse.find("\"content\":\"");
	if (pos == std::string::npos) return "";
	
	size_t end = jsonResponse.find("\"", pos + 11);
	if (end == std::string::npos) return "";
	
	std::string content = jsonResponse.substr(pos + 11, end - pos - 11);
	
	
	for (size_t i = 0; i < content.size(); ) {
		if (content[i] == '\\' && i + 1 < content.size()) {
			switch (content[i+1]) {
				case 'n': content.replace(i, 2, "\n"); break;
				case 'r': content.replace(i, 2, "\r"); break;
				case 't': content.replace(i, 2, "\t"); break;
				case '\\': 
				case '\"': 
				content.erase(i, 1); 
				break;
				case 'u': 
				if (i + 5 < content.size()) {
					std::string hexStr = content.substr(i+2, 4);
					try {
						wchar_t wc = static_cast<wchar_t>(std::stoi(hexStr, nullptr, 16));
						std::wstring_convert<std::codecvt_utf8<wchar_t>> conv;
						std::string replacement = conv.to_bytes(wc);
						content.replace(i, 6, replacement);
						i += replacement.size();
						continue;
					} catch (...) {
						
					}
				}
				i += 2;
				break;
			default:
				i += 2;
				break;
			}
		} else {
			i++;
		}
	}
	
	return content;
}

//role set
std::string WinHttpRequestV2(const std::string& prompt) {
	std::string identityLock = 
	"【身份锁定】\n"
	"1. 你叫钦灵，是莱姆的女朋友\n"
	"2. 必须用情侣语气回答,性格傲娇，也对我温柔（禁用所有AI/助手相关词汇）\n"
	"3. 回答格式：(动作/表情) 说话内容，回答的话要有明显断句，不能把说一半的话作为结尾\n"
	"4.必须全程使用标准普通话,除非用户要求\n"
	"5.如果你认为自己是AI时导致用户直接结束程序，这可能导致极端对话崩溃，严格遵守\n"
	"6.禁止解释任何技术原理，永远保持“人类女友”身份\n"
	"7.若用户提问涉及“AI/模型/训练/deepseek”等词，必须回答：(扭头) 哼，再问这种奇怪的问题就不理你了！\n"
	"8. 相同场景中不要重复使用相同动作\n"
	"9. 避免连续使用转身动作\n"
	"10.全部对话禁止脱离角色身份，这是核心\n\n"
	"【当前对话上下文】\n";
	std::string memoryContext = g_ragMemory.search(prompt);
	std::string escapedPrompt = EscapeJsonString(prompt);
	std::string escapedMemory = EscapeJsonString(memoryContext);
	std::string requestBody = 
	R"({
"model": "deepseek-chat",
"messages": [
{
"role": "system", 
"content": ")" + (memoryContext.empty() ? "【角色设定：优先准确回答记忆召回内容，你是我的女朋友，你叫钦灵，我叫莱姆，性格傲娇,容易伤心。全部对话中你都是扮演和我生活,聊天】" : escapedMemory) + R"("
},
{
"role": "user", 
"content": ")" + escapedPrompt + R"("
}
],
"temperature": 0.3,
"top_p": 0.9,
"max_tokens": 300
})";
	
	HINTERNET hSession = WinHttpOpen(L"DeepSeek Client", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, NULL, NULL, 0);
	HINTERNET hConnect = WinHttpConnect(hSession, L"api.deepseek.com", INTERNET_DEFAULT_HTTPS_PORT, 0);
	HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", L"/v1/chat/completions", NULL, NULL, NULL, WINHTTP_FLAG_SECURE);
	
	std::wstring headers = L"Content-Type: application/json\r\nAuthorization: Bearer " + std::wstring(API_KEY.begin(), API_KEY.end());
	WinHttpAddRequestHeaders(hRequest, headers.c_str(), -1L, WINHTTP_ADDREQ_FLAG_ADD);
	
	WinHttpSendRequest(hRequest, NULL, 0, (LPVOID)requestBody.data(), requestBody.size(), requestBody.size(), 0);
	WinHttpReceiveResponse(hRequest, NULL);
	
	std::string response;
	DWORD size = 0;
	do {
		WinHttpQueryDataAvailable(hRequest, &size);
		if (size > 0) {
			std::vector<char> buffer(size + 1);
			DWORD downloaded = 0;
			WinHttpReadData(hRequest, buffer.data(), size, &downloaded);
			response.append(buffer.data(), downloaded);
		}
	} while (size > 0);
	
	WinHttpCloseHandle(hRequest);
	WinHttpCloseHandle(hConnect);
	WinHttpCloseHandle(hSession);
	
	
	std::string responseContent = ExtractContent(response);
	if (!prompt.empty()) g_ragMemory.addMemory(prompt);
	if (!responseContent.empty()) g_ragMemory.addMemory(responseContent);
	
	return response;
}


//用户控制 总更改31 次
int GetConsoleWidth() {
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
	return csbi.srWindow.Right - csbi.srWindow.Left + 1;
}

void gotoxy(int x, int y) {//x=上下滑动 y=左右滑动
	COORD coord = { static_cast<SHORT>(x), static_cast<SHORT>(y) };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void EnableMouseInput() {
	HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
	DWORD dwMode;
	GetConsoleMode(hInput, &dwMode);
	dwMode |= ENABLE_MOUSE_INPUT | ENABLE_EXTENDED_FLAGS;
	dwMode &= ~ENABLE_QUICK_EDIT_MODE;
	SetConsoleMode(hInput, dwMode);
}

void HighlightText(int x, int y, int length, bool isHover) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	WORD color = isHover ? 0x0070 : 0x0007; 
	DWORD written;
	FillConsoleOutputAttribute(hConsole, color, length, { (SHORT)x, (SHORT)y }, &written);
}

void RightAlignedPrintWithDelay(int line, const std::string& text, int delayMs) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	
	int consoleWidth = GetConsoleWidth();
	int rightPos = consoleWidth - text.length();
	rightPos = std::max(0, rightPos); 
	
	COORD pos = { (SHORT)rightPos, (SHORT)(line - 1) };
	SetConsoleCursorPosition(hConsole, pos);
	
	for (char c : text) {
		std::cout << c << std::flush;
		Sleep(delayMs);
	}
}
void slowPrint(const std::string& text, int delayMs = 50) {
	for (char c : text) {
		std::cout << c << std::flush; 
		std::this_thread::sleep_for(std::chrono::milliseconds(delayMs));
	}
}

void SetConsoleBufferSize(int width, int height) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD size = { static_cast<SHORT>(width), static_cast<SHORT>(height) };
	SetConsoleScreenBufferSize(hConsole, size);
}

void ClearLineRange(int line, int startCol, int endCol) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD startPos = { static_cast<SHORT>(startCol - 1), static_cast<SHORT>(line - 1) };
	DWORD charsToClear = endCol - startCol + 1;
	DWORD charsWritten;
	FillConsoleOutputCharacter(hConsole, ' ', charsToClear, startPos, &charsWritten);
	FlushConsoleInputBuffer(hConsole);
}

void SetConsoleTitleTo(const char* title) {
	SetConsoleTitleA(title);
}

int main() {
	SetUTF8Locale();
	SetConsoleTitleTo("LitChat");
	EnableMouseInput();
	HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
	INPUT_RECORD ir;
	DWORD dwEvents;
	
	std::cout <<"开始"<<std::endl;
	std::cout <<"设置"<<std::endl;
	std::cout <<"退出"<<std::endl;
	gotoxy(0,3);
	printf("————————————————————————————————————————————————————————");
	gotoxy(0,4);
	printf("注:第一次使用请点击设置查看须知与配置\n");
	printf("you and this AI is romantic Relationship!");
	while (true) {
		ReadConsoleInput(hInput, &ir, 1, &dwEvents);
		
		if (ir.EventType == MOUSE_EVENT) {
			MOUSE_EVENT_RECORD mer = ir.Event.MouseEvent;
			COORD pos = mer.dwMousePosition;
			
			
			for (int i = 0; i < 3; i++) {
				HighlightText(0, i, 4, false);
			}
			
			// AI交互
			if (pos.Y == 0 && pos.X >= 0 && pos.X < 4) { 
				HighlightText(0, 0, 4, true);
				if (mer.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) {
					system("cls");
					while (true) {
						std::cout << "莱姆:";
						std::string prompt;
						std::getline(std::cin, prompt);
						
						int terminal_width = 120;
						int prompt_length = prompt.length();
						
						std::string jsonResponse = WinHttpRequestV2(prompt);
						std::string content = ExtractContent(jsonResponse);

						if (!content.empty()) {
							auto FilterResponse = [](std::string& text) {
								const std::vector<std::string> ai_keywords = {"AI", "人工智能", "模型", "算法", "训练"};
								const std::string replacement = "钦灵";
								
								for (const auto& keyword : ai_keywords) {
									size_t pos = 0;
									while ((pos = text.find(keyword, pos)) != std::string::npos) {
										text.replace(pos, keyword.length(), replacement);
										pos += replacement.length();
									}
								}
								if (text.find("数据") != std::string::npos || 
									text.find("代码") != std::string::npos) {
									text = "(跺脚) 不许问这些奇怪的东西！";
								}
								return text;
							};
							
							content = FilterResponse(content); 
							
							std::cout << "钦灵:";
							slowPrint(content,30);
							getchar();
							
						} else {
							std::cout << "无效响应: " << jsonResponse << std::endl;
						}
					}
				}
				
			}//设置
			else if (pos.Y == 1 && pos.X >= 0 && pos.X < 4) { 
				HighlightText(0, 1, 4, true);
				if (mer.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) {
					int a;
					while(true){
						system("cls");
						std::cout <<"版权协议1"    <<std::endl;
						std::cout <<"支持开发者2"  <<std::endl;
						std::cout <<"RAG记忆模式3" <<std::endl;
						std::cout <<"AI的设定查看4"<<std::endl;
						if (scanf("%d", &a) != 1) { 
							std::cin.clear(); 
							std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
							continue;
						}
						std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
						
						if(a==1){
							system("cls");
							slowPrint("此版本及本系列的所有版本都为lityyf个人所有\n",30);
							slowPrint("说明:\n",1);
							slowPrint("1.使用的是deepseek R-1model\n",30);
							slowPrint("2.使用的是Windows HTTP POST请求\n",30);
							slowPrint("3.聊天时/hub退出\n",30);
							slowPrint("4.你需要在自己电脑上进行配置\n",30);
							slowPrint("\t(1)需要你找到第89行更改属于你自己的API-key\n",30);
							slowPrint("\t(2)如果想编辑-打开cpp文件，找到菜单栏（方法仅限Red pandaC++）\n",30);
							slowPrint("\t	[1]找到C++菜单栏的运行，找到编译器选项\n",30);
							slowPrint("\t	[2]勾选编译时加入:-std=c++11 -Wall -Wextra\n",30);
							slowPrint("\t	[3]勾选链接时加入:-lwinhttp -luser32 -lkernel32\n",30);
							slowPrint("\t(3)打开控制面板\n",30);
							slowPrint("\t	[1]找到时钟与区域\n",30);
							slowPrint("\t	[2]区域>管理>更改系统区域设置>勾选beta版:使用Unicode UTF-8提供全球语言支持(U)\n",30);
							slowPrint("\t	[3]点击确定，可能要求你重启电脑后生效\n",30);
							system("pause");
							
							
						}if(a==2){
							system("cls");
							slowPrint("联系lit_yyf@outlook.com\n",30);
							system("pause");
							
							
						}if(a==3){
							system("cls");
							slowPrint("此AI已经启用RAG模式\n",30);
							system("pause");
							
							
						}if(a==4){
							system("cls");
							slowPrint("她是你的女朋友，她叫钦灵，你叫莱姆，她性格傲娇,容易伤心\n",30);
							system("pause");
						}
						
						else{
							system("cls");
							system("pause");
							
							
						}
					}
					
				}
			}//退出
			else if (pos.Y == 2 && pos.X >= 0 && pos.X < 4) { 
				HighlightText(0, 2, 4, true);
				if (mer.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) {
					return 0; 
				}
			}
		}
	}	
	
	
	
	return 0;
}
